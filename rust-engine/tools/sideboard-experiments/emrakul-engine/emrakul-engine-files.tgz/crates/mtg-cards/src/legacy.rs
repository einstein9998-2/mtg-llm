//! The real Legacy card pool (RON), built up card by card against the spec scenarios.

use mtg_core::card::CardDb;
use std::sync::Arc;

pub const LEGACY_CARDS: &str = include_str!("../cards/legacy.cards.ron");

pub const TRON_CARDS: &str = include_str!("../cards/tron.cards.ron");

pub const TRON_SIDE_CARDS: &str = include_str!("../cards/tron-sideboard.cards.ron");

pub const STORM_CARDS: &str = include_str!("../cards/storm.cards.ron");

pub const UR_CARDS: &str = include_str!("../cards/ur.cards.ron");

pub const BOROS_CARDS: &str = include_str!("../cards/boros.cards.ron");

pub const EMRAKUL_CARDS: &str = include_str!("../cards/emrakul.cards.ron");

pub fn build() -> Arc<CardDb> {
    let db = mtg_dsl::build_db(&[("legacy.cards.ron", LEGACY_CARDS), ("tron.cards.ron", TRON_CARDS), ("tron-sideboard.cards.ron", TRON_SIDE_CARDS), ("storm.cards.ron", STORM_CARDS), ("ur.cards.ron", UR_CARDS), ("boros.cards.ron", BOROS_CARDS), ("emrakul.cards.ron", EMRAKUL_CARDS)]).unwrap_or_else(|e| panic!("legacy pool failed to load: {e}"));
    Arc::new(db)
}
